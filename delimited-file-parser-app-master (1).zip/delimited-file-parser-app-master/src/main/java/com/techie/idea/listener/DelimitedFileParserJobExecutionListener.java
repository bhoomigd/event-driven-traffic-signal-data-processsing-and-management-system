package com.techie.idea.listener;

import com.techie.idea.config.DelimitedFileParserConfigProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

import static com.techie.idea.util.AppConstants.INPUT_FILE_HEADERS;
import static com.techie.idea.util.AppConstants.INPUT_FILE_NAME;

@Component
@Slf4j
@RequiredArgsConstructor
public class DelimitedFileParserJobExecutionListener implements JobExecutionListener {

    private final DelimitedFileParserConfigProperties delimitedFileParserConfigProperties;
    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("Before job execution");
        //region can be like ASIAPACIFIC,AMERICAS,EUR,etc...This is set in
        final String region = jobExecution.getJobParameters().getString("region");
//        String region = "EUR";
        File directory = delimitedFileParserConfigProperties.getInputPath().resolve(Objects.requireNonNull(region)).toFile();
        if(!directory.isDirectory()){
            throw new IllegalArgumentException(directory + "is no directory.");
        }

        FilenameFilter patternFilter = new WildcardFileFilter(String.format(delimitedFileParserConfigProperties.getFilenamePattern(),region), IOCase.INSENSITIVE);
        File[] fileList = directory.listFiles(patternFilter);
        if(ArrayUtils.isEmpty(fileList)){
            log.error("no .dat input file found");
            throw new RuntimeException(String.format("no .dat input file found"));
        } else if (fileList.length == 1) {
            log.info(">>> .DAT input file found ");
            jobExecution.getExecutionContext().put(INPUT_FILE_NAME,fileList[0].getAbsolutePath());
            String[] fileHeaders = delimitedFileParserConfigProperties.getFileHeaders();
            jobExecution.getExecutionContext().put(INPUT_FILE_HEADERS,fileHeaders);

        }


    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        log.info("After job execution - Status: {}", jobExecution.getStatus());

        if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
            String inputFilePath = jobExecution.getExecutionContext().getString(INPUT_FILE_NAME);
            String region = jobExecution.getJobParameters().getString("region");

            if (inputFilePath != null && region != null) {
                Path inputFile = Paths.get(inputFilePath);

                // ✅ Create region-specific archive directory
                Path regionArchiveDir = delimitedFileParserConfigProperties.getArchivePath().resolve(region);

                try {
                    if (!Files.exists(regionArchiveDir)) {
                        Files.createDirectories(regionArchiveDir);
                        log.info("Created region archive folder: {}", regionArchiveDir);
                    }

                    // Optional: append timestamp to file name to avoid overwrite
                    String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
                    String newFileName = inputFile.getFileName().toString().replace(".dat", "_" + timestamp + ".dat");

                    Path archivedFile = regionArchiveDir.resolve(newFileName);
                    Files.move(inputFile, archivedFile, StandardCopyOption.REPLACE_EXISTING);

                    log.info("✅ File archived successfully for region '{}': {}", region, archivedFile);

                } catch (IOException e) {
                    log.error("Error moving file to archive for region {}: {}", region, e.getMessage(), e);
                }
            } else {
                log.warn("Input file or region missing in execution context — skipping archiving.");
            }

        } else {
            log.warn("Job did not complete successfully. Skipping file archiving.");
        }
    }
}
