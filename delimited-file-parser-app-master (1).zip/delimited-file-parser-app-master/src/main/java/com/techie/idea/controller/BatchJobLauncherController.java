package com.techie.idea.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/launch")
public class BatchJobLauncherController {

    private static final Logger logger = LoggerFactory.getLogger(BatchJobLauncherController.class);

    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private Job readAndPublishDelimitedFileParserJob;

    /**
     * Launches the Spring Batch job for a given region and provides
     * clear success or failure responses.
     */
    @GetMapping("/readAndPublishDelimitedFileParserJob/job/{regionInfo}")
    public ResponseEntity<Map<String, Object>> jobLauncher(@PathVariable String regionInfo) {

        Map<String, Object> response = new HashMap<>();

        try {
            // Build job parameters
            JobParameters jobParameters = new JobParametersBuilder()
                    .addString("region", regionInfo)
                    .addLong("time", System.currentTimeMillis())
                    .toJobParameters();

            logger.info("Launching Batch Job for region: {}", regionInfo);

            // Run the job
            JobExecution jobExecution = jobLauncher.run(readAndPublishDelimitedFileParserJob, jobParameters);

            // Check job status
            switch (jobExecution.getStatus()) {
                case COMPLETED:
                    response.put("status", "SUCCESS");
                    response.put("message", "Job executed successfully and file moved to archive for region: " + regionInfo);
                    response.put("jobId", jobExecution.getJobId());
                    logger.info("✅ Batch Job completed successfully and file archived for region: {}", regionInfo);
                    return ResponseEntity.ok(response);

                case FAILED:
                    // Extract only the main error message (not full stack trace)
                    String exitDescription = jobExecution.getExitStatus().getExitDescription();
                    String shortError = extractRootCause(exitDescription);

                    response.put("status", "FAILURE");
                    response.put("message", "Job execution failed for region: " + regionInfo + ". File was not moved to archive.");
                    response.put("exitStatus", shortError);

                    logger.error("❌ Batch Job failed for region {}. Root cause: {}", regionInfo, shortError);
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);

                default:
                    response.put("status", jobExecution.getStatus().toString());
                    response.put("message", "Job ended with status: " + jobExecution.getStatus());
                    logger.warn("⚠️ Batch Job ended with non-standard status: {}", jobExecution.getStatus());
                    return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
            }

        } catch (Exception e) {
            logger.error("💥 Error while launching batch job for region {}: {}", regionInfo, e.getMessage(), e);
            response.put("status", "ERROR");
            response.put("message", "Failed to launch batch job for region: " + regionInfo + ". Reason: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    /**
     * Utility method to extract the main issue from an exception stack trace or exit description.
     * For example: "java.lang.RuntimeException: no .dat input file found" → "no .dat input file found"
     */
    private String extractRootCause(String exitDescription) {
        if (exitDescription == null || exitDescription.isEmpty()) {
            return "Unknown error";
        }
        // Only take the first line (root cause message)
        String[] lines = exitDescription.split("\\r?\\n");
        String firstLine = lines[0].trim();

        // Remove class name prefix if present
        if (firstLine.contains(":")) {
            return firstLine.substring(firstLine.indexOf(":") + 1).trim();
        }
        return firstLine;
    }
}
